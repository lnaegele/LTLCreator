The jar-File is runnable by double-click (or "java -jar LTLCreator_standalone.jar" in the console).

In this standalone editor a state machine is predefined, information about this in "stm.pdf".

By clicking the magic wand on the left (in the editor), the constraint genereator starts working.
For the constraint validation, the symbolic model checker NuSMV is used. If LTLCreator asks you about the location of NuSMV,
just tell it the /NuSMV/bin/NuSMV.exe.